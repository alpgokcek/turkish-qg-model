import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";

const Dashboard = () => {
  const [videoId, setVideoId] = useState(
    "1p-A3uKngCw"
  );
  const [startAt, setStartAt] = useState("0");

  const [videoLink, setVideoLink] = useState("");

  useEffect(() => {
    (videoId && startAt) && setVideoLink(`https://www.youtube.com/embed/${videoId}?autoplay=1&start=${startAt}`)
  }, [videoId, startAt])
  const iframeVideo = (
    <iframe
      width="100%"
      height="541"
      src={ videoLink }
      frameBorder="0"
      title="YouTube Video"
      allowFullScreen />
  );

  return (
    <div>
      <div>
        <label>Video Link</label><br/>
        <input
          type="text"
          value={videoId}
          onChange={(e) => setVideoId(e.target.value)}
        />
        {videoId && iframeVideo}
        <div onClick={()=>setStartAt("50")}>Click Here to Start At 50 seconds</div>
      </div>
    </div>
  );
};

Dashboard.propTypes = {};

export default Dashboard;
